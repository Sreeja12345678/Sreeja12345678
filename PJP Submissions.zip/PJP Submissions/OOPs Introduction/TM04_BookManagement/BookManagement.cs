﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TM04_BookManagement
{
    class BookManagement
    {
        static Book[] Rack = new Book[10];

        static int i = 0;
        public void AddBook()
        {
            string ISBN, BookName;
            int YearPublished;
            decimal Price;

            Console.WriteLine("Enter ISBN of Book:");
            ISBN=Console.ReadLine();
            Console.WriteLine("Enter Book Name:");
            BookName = Console.ReadLine();
            Console.WriteLine("Enter Year in which Book is Published:");
            YearPublished = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Book Price:");
            Price = Convert.ToDecimal(Console.ReadLine());

            string AuthorName, AuthorEmail;
            char Gender;
            Console.WriteLine("Enter Author Name:");
            AuthorName = Console.ReadLine();
            Console.WriteLine("Enter Author Email:");
            AuthorEmail = Console.ReadLine();
            Console.WriteLine("Enter Author Gender:");
            Gender = Convert.ToChar(Console.ReadLine());
            Author A1 = new Author(AuthorName, AuthorEmail, Gender);
            Book B1 = new Book(ISBN,BookName,YearPublished,Price,A1);
            Rack[i] = B1;
            i++;
        }

        public bool SearchBook(string ISBN)
        {
            foreach(Book i in Rack)
            {
                if (i == null)
                {
                    break;
                }
                if (i.getISBN() == ISBN)
                {
                    Console.WriteLine("True");
                    return true;
                }
            }
            Console.WriteLine("False");
            return false;
        }

        public void ViewBooks()
        {
            foreach(Book i in Rack)
            {
                if (i == null)
                {
                    break;
                }
                i.BookDetails();
            }
        }

        public void ViewAuthors()
        {

            foreach(Book i in Rack)
            {
                if (i == null)
                {
                    break;
                }
                i.getAuthor().DisplayAuthorDetails();
            }
        }

        public void UpdateBook()
        {
            string ISBN;
            int flag = 0;
            Console.WriteLine("Enter ISBN of Book:");
            ISBN = Console.ReadLine();
            for(int i=0;i<10;i++)
            {
                if (Rack[i] == null)
                {
                    break;
                }
                if (Rack[i].getISBN() == ISBN)
                {

                    string BookName;
                    int YearPublished;
                    decimal Price;

                    Console.WriteLine("Enter ISBN of Book:");
                    ISBN = Console.ReadLine();
                    Console.WriteLine("Enter Book Name:");
                    BookName = Console.ReadLine();
                    Console.WriteLine("Enter Year in which Book is Published:");
                    YearPublished = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Book Price:");
                    Price = Convert.ToDecimal(Console.ReadLine());

                    string AuthorName, AuthorEmail;
                    char Gender;
                    Console.WriteLine("Enter Author Name:");
                    AuthorName = Console.ReadLine();
                    Console.WriteLine("Enter Author Email:");
                    AuthorEmail = Console.ReadLine();
                    Console.WriteLine("Enter Author Gender:");
                    Gender = Convert.ToChar(Console.ReadLine());
                    Author A1 = new Author(AuthorName, AuthorEmail, Gender);
                    Book B1 = new Book(ISBN, BookName, YearPublished, Price, A1);
                    Rack[i] = B1;
                    flag = 1;
                }
            }
            if (flag == 0)
            {
                Console.WriteLine($"Book with ISBN: {ISBN} is not found in Rack");
            }
            else
            {
                Console.WriteLine($"Book Updated Successfully!");
            }
        }
    }
}
