﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TM04_BookManagement
{
    class Book
    {
        string ISBN, BookName;
        int YearPublished;
        decimal Price;
        Author AuthorDetails;
        
        public Author getAuthor()
        {
            return this.AuthorDetails;
        }
        public string getISBN()
        {
            return this.ISBN;
        }
        public Book(string ISBN,string BookName,int YearPublished,decimal Price,Author AuthorDetails)
        {
            this.ISBN = ISBN;
            this.BookName = BookName;
            this.YearPublished = YearPublished;
            this.Price = Price;
            this.AuthorDetails = AuthorDetails;
        }

        public void BookDetails()
        {
            Console.WriteLine("*****Book Details*****");
            Console.WriteLine($"ISBN: {this.ISBN}");
            Console.WriteLine($"Book Name: {this.BookName}");
            Console.WriteLine($"Year in which {this.BookName} is Published: {this.YearPublished}");
            Console.WriteLine($"Book Price: {this.Price}");
            this.AuthorDetails.DisplayAuthorDetails();

        }
    }
}
