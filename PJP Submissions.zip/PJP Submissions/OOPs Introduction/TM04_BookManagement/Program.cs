﻿using System;

namespace TM04_BookManagement
{
    class Program
    {
        static int Menu()
        {
            Console.WriteLine("Enter number of any task you want to perform from Menu");
            Console.WriteLine("1. Add Book");
            Console.WriteLine("2. Search Book");
            Console.WriteLine("3. Update Book");
            Console.WriteLine("4. View All Books");
            Console.WriteLine("5. View all Authors");
            Console.WriteLine("6. Exit");
            int x;
            x = Convert.ToInt32(Console.ReadLine());
            return x;
        }
        static void Main(string[] args)
        {
            int x;
            do {
                x = Menu();
                BookManagement B1 = new BookManagement();
                switch (x)
                {
                    case 1:
                        B1.AddBook();
                        break;
                    case 2:
                        Console.WriteLine("Enter ISBN:");
                        string ISBN = Console.ReadLine();
                        B1.SearchBook(ISBN);
                        break;
                    case 3:
                        B1.UpdateBook();
                        break;
                    case 4:
                        B1.ViewBooks();
                        break;
                    case 5:
                        B1.ViewAuthors();
                        break;
                    default:
                        break;
                }
            } while (x<6 && x>0);
        }
    }
}
