﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TM04_BookManagement
{
    class Author
    {
        string AuthorName,AuthorEmail;
        char Gender;

        public Author(string AuthorName,string AuthorEmail,char Gender)
        {
            this.AuthorName = AuthorName;
            this.AuthorEmail = AuthorEmail;
            this.Gender = Gender;
        }
        public void DisplayAuthorDetails()
        {
            Console.WriteLine("*****Author Details*****");
            Console.WriteLine($"Author Name: {this.AuthorName}");
            Console.WriteLine($"Author Email: {this.AuthorEmail}");
            Console.WriteLine($"Author Gender: {this.Gender}");
            Console.WriteLine();
        }
    }
}
