﻿using System;

namespace MethodsProperties01
{
    class Employee
    {
        string _EmpName;
        decimal _BasicSalary, HRA, DA, TAX, GrossPay, NetSalary;
       public Employee(string EmpName,decimal BasicSalary)
        {
            this._EmpName = EmpName;
            this._BasicSalary = BasicSalary;
        }
        public void CalculateNetPay()
        {
            HRA = ((decimal)(15.0 / 100)) * _BasicSalary;
            DA = ((decimal)(10.0 / 100)) * _BasicSalary;
            GrossPay = _BasicSalary + HRA + DA;
            TAX = ((decimal)(8.0 / 100)) * GrossPay;
            NetSalary = GrossPay - TAX;
        }
        public void Display()
        {
            Console.WriteLine("*****Salary Structure*****");
            Console.WriteLine($"Basic Salary: {_BasicSalary}");
            Console.WriteLine($"HRA: {HRA}");
            Console.WriteLine($"DA: {DA}");
            Console.WriteLine($"Gross Pay: {GrossPay}");
            Console.WriteLine($"TAX: {TAX}");
            Console.WriteLine($"Net Salary: {NetSalary}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            string EmpName;
            decimal BasicSalary;
            Console.Write("Enter Employee Name:");
            EmpName = Console.ReadLine();
            Console.Write("Enter Basic Salary:");
            BasicSalary = Convert.ToDecimal(Console.ReadLine());
            Employee e1 = new Employee(EmpName, BasicSalary);
            e1.CalculateNetPay();
            e1.Display();
        }
    }
}
