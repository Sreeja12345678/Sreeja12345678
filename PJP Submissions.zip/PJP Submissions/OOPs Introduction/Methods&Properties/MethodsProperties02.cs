﻿using System;

namespace MethodsProperties02
{
    class Program
    {
        class Stock
        {
            string _StockName;
            string _StockSymbol;
            double _prevClosingPrice;
            double _currClosingPrice;
            public Stock(string StockName,string StockSymbol,double prevClosingPrice,double currClosingPrice)
            {
                this._StockName = StockName;
                this._StockSymbol = StockSymbol;
                this._prevClosingPrice = prevClosingPrice;
                this._currClosingPrice = currClosingPrice;
            }
            public double getChangePercentage()
            {

                if (_currClosingPrice > _prevClosingPrice)
                {
                    return ((_currClosingPrice - _prevClosingPrice) / _currClosingPrice) * 100;
                }
                else
                {
                    return ((_prevClosingPrice - _currClosingPrice) / _prevClosingPrice) * 100;
                }
                
            }
        }
        static void Main(string[] args)
        {
            string StockName;
            string StockSymbol;
            double prevClosingPrice;
            double currClosingPrice;
            Console.Write("Enter Stock Name:");
            StockName = Console.ReadLine();
            Console.Write("Enter Stock Symbol:");
            StockSymbol = Console.ReadLine();
            Console.Write("Enter Previous Closing Price:");
            prevClosingPrice = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Current Closing Price:");
            currClosingPrice = Convert.ToDouble(Console.ReadLine());
            Stock s1 = new Stock(StockName, StockSymbol, prevClosingPrice, currClosingPrice);
            Console.WriteLine($"Percentage Change in {StockName} Stock Price is {s1.getChangePercentage()}%");
        }
    }
}
