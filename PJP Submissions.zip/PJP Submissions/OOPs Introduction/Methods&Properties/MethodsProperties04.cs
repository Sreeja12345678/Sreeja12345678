﻿using System;

namespace MethodsProperties04
{
    class Fan
    {
        static int SLOW = 1, MEDIUM = 2, FAST = 3;
        private int speed = SLOW;
        private bool on = false;
        private double radius = 5;
        private string color = "red";
        public Fan()
        {

        }
        public int Speed
        {
            set
            {
                if (value == 1 || value == 2 || value == 3)
                {
                    this.speed = value;
                }
            }
            get
            {
                return this.speed;
            }
        }
        public bool ON
        {
            set
            {
                if (value == true || value == false)
                {
                    this.on = value;
                }
            }
            get
            {
                return this.on;
            }
        }
        public double Radius
        {
            set
            {
                this.radius = value;
            }
            get
            {
                return this.radius;
            }
        }
        public string Color
        {
            set
            {
                this.color = value;
            }
            get
            {
                return this.color;
            }
        }
        public void toString()
        {
            Console.WriteLine("*****FAN STATUS*****");
            Console.WriteLine($"Speed: {this.speed}");
            Console.WriteLine($"ON/OFF Status: {this.on}");
            Console.WriteLine($"Radius:{this.radius}");
            Console.WriteLine($"Color: {this.color}");
        }
    }
        class Program
        {
            static void Main(string[] args)
            {
            int speed;
            bool on;
            double radius;
            string color;
                Console.WriteLine("Enter speed of Fan(1,2,3)");
            speed = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Fan ON/OFF status(true,false)");
            on = Convert.ToBoolean(Console.ReadLine());
            Console.WriteLine("Enter radius of Fan");
            radius = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Fan Color");
            color = Console.ReadLine();
            Fan f1 = new Fan();
            f1.Speed = speed;
            f1.ON = on;
            f1.Radius = radius;
            f1.Color = color;
            f1.toString();
            }
        }
    
}