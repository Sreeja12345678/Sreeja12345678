﻿using System;

namespace MethodsProperties03
{
    class RandomHelper
    {
        public static int randint(int min,int max)
        {
            Random rnd = new Random();
            int x = rnd.Next(min, max + 1);
            return x;
        }
        public static double randdouble(double min, double max)
        {

            Random rnd = new Random();
            double x = rnd.NextDouble()*(max-min)+min;
            return x;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Integer Max Value:");
            int maxInt = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Integer Min Value:");
            int minInt = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"Random Generated Integer: {RandomHelper.randint(minInt, maxInt)}");
            Console.Write("Enter Double Max Value:");
            double maxdouble = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Double Min Value:");
            double mindouble = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"Random Generated Double: {RandomHelper.randdouble(mindouble, maxdouble)}");
            

        }
    }
}
