﻿using System;

namespace ClassInCS01
{
    class Car
    {
        string _carmake;
        int _MfgYear;
        string _CarModel;
        string _City;

        public Car(String carmake,int MfgYear,string CarModel,string City)
        {
            this._carmake = carmake;
            this._MfgYear = MfgYear;
            this._CarModel = CarModel;
            this._City = City;
        }
        public void DisplayDetails()
        {
            Console.WriteLine("Car Details:");
            Console.WriteLine($"CarMake:{this._carmake}");
            Console.WriteLine($"MgfYear:{this._MfgYear}");
            Console.WriteLine($"CarModel:{this._CarModel}");
            Console.WriteLine($"City:{this._City}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Car c1 = new Car("Ford", 2000, "Ford Figo", "California");
            c1.DisplayDetails();
        }
    }
}
