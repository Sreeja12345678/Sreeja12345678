﻿using System;

namespace DataTypes02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string");
            string S = Console.ReadLine();
            int NoOfDigits = 0;
            int NoOfAlphabets = 0;
            foreach(char i in S)
            {
                if ((i >= 'A' && i <= 'Z') || (i >= 'a' && i <= 'z'))
                {
                    NoOfAlphabets++;
                }
                if (i >= '0' && i <= '9')
                {
                    NoOfDigits++;
                }
            }
            Console.WriteLine("No of Digits in String {0} is {1}", S, NoOfDigits);
            Console.WriteLine("No of Alphabets in string {0} is {1}", S, NoOfAlphabets);
        }
    }
}
