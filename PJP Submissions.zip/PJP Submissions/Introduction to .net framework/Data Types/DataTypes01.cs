﻿using System;

namespace DataTypes01
{
    class AreaOfSquare
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the side of square");
            double side = Convert.ToDouble(Console.ReadLine());
            double area = side * side;
            Console.WriteLine("Area Of Square is " + area);
        }
    }
}
