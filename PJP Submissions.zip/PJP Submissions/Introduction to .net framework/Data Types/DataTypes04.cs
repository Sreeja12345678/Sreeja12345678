﻿using System;

namespace DataTypes04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string");
            string S = Console.ReadLine();
            foreach(char i in S)
            {
                if(i>='a' && i <= 'z')
                {
                    Console.Write(Char.ToUpper(i));
                }
                else if(i>='A' && i <= 'Z')
                {
                    Console.Write(Char.ToLower(i));
                }
            }
        }
    }
}
