﻿
using System;

namespace DataTypes03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string");
            string S = Console.ReadLine();
            foreach(char i in S)
            {
                Console.Write((char)(i + 1));
            }
        }
    }
}
