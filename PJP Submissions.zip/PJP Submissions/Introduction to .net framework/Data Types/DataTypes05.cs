﻿using System;

namespace DataTypes05
{
    class Program
    {
        static void Reverse(string S)
        {
            char[] CharArray = S.ToCharArray();
            Array.Reverse(CharArray);
            Console.WriteLine("Reverse of {0}: {1}",S,new string(CharArray));
        }
        static void SecondTillEnd(string S)
        {
            Console.Write($"String {S} from 2nd Position: ");
            for(int i = 1; i < S.Length; i++)
            {
                Console.Write(S[i]);
            }
            Console.WriteLine();
        }
        static void ReplaceChar(string S)
        {
            Console.WriteLine("Enter a char which you wnat to replace");
            char ch = Console.ReadLine()[0];
            int flag = 0;
            string result = "";
            foreach(char i in S)
            {
                if (i == ch)
                {
                    result += '$';
                    flag = 1;
                }
                else
                {
                    result += i;
                }
            }
            if (flag == 0)
            {
                Console.WriteLine($"Char {ch} not found");
                return;
            }
            Console.WriteLine($"string {S} with replaced char {ch}: {result}");
        }
        static void ModifyString(string S)
        {
            string S2 = S;
            S2 += "_Modified";
            Console.WriteLine($"Original String: {S}");
            Console.WriteLine($"Modified String: {S2}");
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string");
            string S = Console.ReadLine();
            Reverse(S);
            Console.WriteLine();
            SecondTillEnd(S);
            Console.WriteLine();
            ReplaceChar(S);
            Console.WriteLine();
            ModifyString(S);
        }
    }
}
