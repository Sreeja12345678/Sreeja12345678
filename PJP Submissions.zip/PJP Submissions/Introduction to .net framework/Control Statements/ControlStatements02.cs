﻿using System;

namespace ControlStatements02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Two Numbers");
            var l = Console.ReadLine().Split(' ');
            int a = int.Parse(l[0]);
            int b = int.Parse(l[1]);

            string p = a.ToString();
            string q = b.ToString();
            Console.WriteLine(a);
            Console.WriteLine(b);
            int flag = -1;
            for(int i = p.Length-1; i >= 0; i--)
            {
                if (p[i] == q[0])
                {
                    flag = i;
                }

            }
            if (flag == -1)
            {
                Console.WriteLine($"{b} is not present in {a}");
            }
            switch (p.Length - flag)
            {
                case 1:
                    Console.WriteLine($"{b} is at unit's place in {a}");
                    break;
                case 2:
                    Console.WriteLine($"{b} is at ten's place in {a}");
                    break;
                case 3:
                    Console.WriteLine($"{b} is at hundereds place in {a}");
                    break;
                case 4:
                    Console.WriteLine($"{b} is at thousands place in {a}");
                    break;
            }
        }
    }
}
