﻿using System;

namespace ControlStatements
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string");
            string S = Console.ReadLine();
            char[] chararray = S.ToCharArray();
            Array.Reverse(chararray);
            string s1 = new string(chararray);
            if (S == s1)
            {
                Console.WriteLine($"{S} is a Palindrome");
            }
            else
            {
                Console.WriteLine($"{S} is not a palindrome");
            }
        }
    }
}
