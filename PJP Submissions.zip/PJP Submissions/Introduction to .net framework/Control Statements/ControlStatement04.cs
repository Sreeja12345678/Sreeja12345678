﻿using System;

namespace Controlstatements04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter two Numbers");
            var l = Console.ReadLine().Split(' ');
            int num1 = int.Parse(l[0]);
            int num2 = int.Parse(l[1]);
            int a = num1;
            int count = 0;
            while (a > 0)
            {
                if (a % 10 == num2)
                {
                    count++;
                }
                a /= 10;
            }
            Console.WriteLine($"{num2} repeated {count} times in {num1}");
        }
    }
}
