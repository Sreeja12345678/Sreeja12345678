﻿using System;

namespace ControlStatements03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Charater");
            char ch = Convert.ToChar(Console.ReadLine());
            if(ch>='0' && ch <= '9')
            {
                Console.WriteLine($"{ch} is a Number");
            }
            else if((ch>='A' && ch<='Z')||(ch>='a' && ch<='z')){
                Console.WriteLine($"{ch} is an Alphabet");
            }
            else
            {
                Console.WriteLine($"{ch} is neither a Number nor an Alphabet");
            }
        }
    }
}
