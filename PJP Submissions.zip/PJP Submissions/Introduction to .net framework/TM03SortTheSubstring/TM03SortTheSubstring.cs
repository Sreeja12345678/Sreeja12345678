﻿using System;

namespace TM03SortTheSubstring
{
    class Program
    {
        static void Main(string[] args)
        {
            int T;
            T = Convert.ToInt32(Console.ReadLine());
            string[] ans = new string[T];
            int i = 0;
            while (T > 0)
            {
                string S = Console.ReadLine();
                var l = Console.ReadLine().Split(' ');
                int N = Convert.ToInt32(l[0]);
                int M = Convert.ToInt32(l[1]);
                if (N == 0) { M++; }
                string s1=S.Substring(0,N);
                string s2 = S.Substring(N, M);
                if (N == 0) { M--; }
                string s3 = S.Substring(M+1);
                char[] arr = s2.ToCharArray();
                Array.Sort(arr);
                Array.Reverse(arr);
                string result = String.Join("",arr);
                result = s1 + result + s3;
                ans[i] = result;
                T--;
                i++;
            }
            foreach(string j in ans)
            {
                Console.WriteLine(j);
            }
        }
    }
}

