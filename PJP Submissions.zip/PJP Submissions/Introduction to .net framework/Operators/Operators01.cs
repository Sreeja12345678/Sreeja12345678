﻿using System;

namespace Operators
{
    class Program
    {
        static void preIncrementing(int num1, int num2)
        {
            num2 = ++num1;
            Console.WriteLine($"Pre-Incrementing(num2=++num1): {num2}");
        }
        static void postIncrementing(int num1, int num2)
        {
            num2 = num1++;
            Console.WriteLine($"Post-Incrementing(num2=num1++): {num2}");
        }
        static void Swap(ref int a, ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter two Numbers");
            var l = Console.ReadLine().Split(' ');
            int num1 = int.Parse(l[0]);
            int num2 = int.Parse(l[1]);
            preIncrementing(num1, num2);
            postIncrementing(num1, num2);
            Swap(ref num1, ref num2);
            Console.WriteLine($"Values after Swapping: Num1={num1} Num2={num2}");

        }
    }
}