﻿using System;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[]{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int size = 0;
            foreach(int i in arr)
            {
                size++;
            }
            Console.WriteLine($"No. of Elements in an array are {size}");
        }
    }
}
