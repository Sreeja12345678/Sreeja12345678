﻿using System;

namespace Array02
{
    class Program
    {
        static void Reverse(int[] arr)
        {
            for(int i = 0, j = arr.Length - 1; i <= j; i++, j--)
            {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            Console.WriteLine("Elements of array after Reversal:");
            foreach(int i in arr)
            {
                Console.Write($"{i} ");
            }
        }
        static void Main(string[] args)
        {
            int[] arr = new int[10];
            Console.WriteLine("Enter 10 Numbers");
            for(int i = 0; i < 10; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Reverse(arr);

        }
    }
}
