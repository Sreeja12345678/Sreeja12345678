﻿using System;

namespace Arrays03
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[10];
            int Sum = 0;
            Console.WriteLine("Enter 10 Numbers");
            for(int i = 0; i < 10; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
                Sum += arr[i];
            }
            Console.WriteLine($"Sum of 10 inputted is {Sum}");
        }
    }
}
