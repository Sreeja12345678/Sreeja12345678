﻿using System;

namespace Polymorphism03
{
    class Math
    {
        public int Add(int a,int b)
        {
            return a + b;
        }
        public int Add(int a, int b,int c)
        {
            return a + b + c;
        }
        public int Substract(int a, int b)
        {
            return a - b;
        }
        public int Substract(int a, int b,int c)
        {
            return a - b - c;
        }
        public int Multiply(int a, int b)
        {
            return a * b;
        }
        public int Multiply(int a, int b,int c)
        {
            return a * b * c;
        }
        public double Divide(double a, double b)
        {
            return a / b;
        }
        public double Divide(double a, double b,double c)
        {
            return a/b/c;
        }
    }
    class Polymorphism03
    {
        static void Main(string[] args)
        {
            Math m1 = new Math();
            Console.WriteLine($"Addition of 5 and 4 is: {m1.Add(5, 4)}");
            Console.WriteLine($"Addition of 5,3 and 4 is: {m1.Add(5,3,4)}");
            Console.WriteLine($"Substraction of 5 and 4 is: {m1.Substract(5,4)}");
            Console.WriteLine($"Substraction of 5,3 and 4 is: {m1.Substract(5,3, 4)}");
            Console.WriteLine($"Multiplication of 5 and 4 is: {m1.Multiply(5, 4)}");
            Console.WriteLine($"Multiplication of 5,3 and 4 is: {m1.Multiply(5,3, 4)}");
            Console.WriteLine($"Division of 5 and 4 is: {m1.Divide(5, 4)}");
            Console.WriteLine($"Division of 5,3 and 4 is: {m1.Divide(5,3, 4)}");
        }
    }
}
