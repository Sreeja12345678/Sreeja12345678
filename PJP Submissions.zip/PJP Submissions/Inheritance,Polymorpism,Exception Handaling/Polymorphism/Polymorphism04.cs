﻿using System;

namespace Polymorphism04
{
    class SuperDuck{
    public virtual void eat()
        {

        }
    }
    class MYDuck:SuperDuck
    {
        public override void eat()
        {
            Console.WriteLine("I am eating food...");
        }
    }
    class ToyDuck : SuperDuck
    {
        public override void eat()
        {
            Console.WriteLine("My food is electrons...");
        }
    }
    class Duck
    {
        public int Menu()
        {
            Console.WriteLine("1. Press 1 for Feeding your duck");
            Console.WriteLine("2. Press 2 for Feeding the Toy duck");
            return Convert.ToInt32(Console.ReadLine());
        }
    }
    class Polymorphism04
    {
        static void Main(string[] args)
        {
            Duck d1 = new Duck();
            int choice = d1.Menu();
            if (choice == 1)
            {
                MYDuck m1 = new MYDuck();
                m1.eat();
            }
            else
            {
                ToyDuck t1 = new ToyDuck();
                t1.eat();
            }
        }
    }
}
