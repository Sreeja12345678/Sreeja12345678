﻿using System;

namespace Polymorphism02
{
    class Polymorphism02
    {
        public static void area(double radius)
        {
            Console.WriteLine($"Area of Circle is: {Math.PI * radius * radius}");
        }
        public static void area(double Tbase,double height)
        {
            Console.WriteLine($"Area of Triangle is: {(Tbase * height)/2}");
        }
        public static void area(decimal side)
        {
            Console.WriteLine($"Area of Circle is: {side * side}");
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter radius of Circle");
            double radius = Convert.ToDouble(Console.ReadLine());
            area(radius);
            Console.WriteLine();
            Console.WriteLine("Enter Base of Triangle");
            double Tbase = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Height of Triangle");
            double Height = Convert.ToDouble(Console.ReadLine());
            area(Tbase,Height);
            Console.WriteLine();
            Console.WriteLine("Enter side of Rectangle");
            decimal side = Convert.ToDecimal(Console.ReadLine());
            area(side);
            Console.WriteLine();
        }
    }
}
