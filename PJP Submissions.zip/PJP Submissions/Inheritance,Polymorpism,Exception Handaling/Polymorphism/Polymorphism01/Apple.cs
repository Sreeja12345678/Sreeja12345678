﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Polymorphism01
{
    class Apple:Fruit
    {
       

        public override void eat()
        {
            name = "Apple";
            taste = "Sweet";
            Console.WriteLine($"Name of Fruit: {name}");
            Console.WriteLine($"Taste of Fruit: {taste}");
            Console.WriteLine();
        }


    }
}
