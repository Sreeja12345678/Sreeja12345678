﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Polymorphism01
{
    class Orange:Fruit
    {
        public override void eat()
        {
            name = "Orange";
            taste = "Sour";
            Console.WriteLine($"Name of Fruit: {name}");
            Console.WriteLine($"Taste of Fruit: {taste}");
            Console.WriteLine();
        }

    }
}
