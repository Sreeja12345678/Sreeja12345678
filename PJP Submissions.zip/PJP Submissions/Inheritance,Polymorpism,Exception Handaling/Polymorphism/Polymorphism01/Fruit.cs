﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Polymorphism01
{
    class Fruit
    {
        public string name="", taste, size;

        public virtual void eat()
        {
            Console.WriteLine($"Name of Fruit: {name}");
            Console.WriteLine($"Taste of Fruit: {taste}");
            Console.WriteLine();
        }
    }
}
