﻿using System;

namespace Polymorphism01
{
    class Program
    {
        static void Main(string[] args)
        {
            Apple A1 = new Apple();
            A1.eat();
            Orange o1 = new Orange();
            o1.eat();
        }
    }
}
