﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inheritance
{
    class PermanentEmployee:IPayable
    {
        public double HRA, DA, Tax, NetPay, TotalPay;
        public PermanentEmployee(double HRA,double DA,double Tax,double NetPay)
        {
            this.HRA = HRA;
            this.DA = DA;
            this.Tax = Tax;
            this.NetPay = NetPay;
        }
        
         public double CalculatePay()
        {
         
            double GrossPay = NetPay + HRA + DA;
            TotalPay = GrossPay - Tax;
            return TotalPay;
        }
    }
}
