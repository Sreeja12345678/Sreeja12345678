﻿using System;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            string FirstName, LastName, EmailAddress;
            DateTime DateofBirth;

            Console.WriteLine("Enter FirstName");
            FirstName = Console.ReadLine();
            Console.WriteLine("Enter LastName");
            LastName = Console.ReadLine();
            Console.WriteLine("Enter EmailAddress");
            EmailAddress = Console.ReadLine();
            Console.WriteLine("Enter Date of Birth");
            DateofBirth = Convert.ToDateTime(Console.ReadLine()); 
            Employee E1 = new Employee(FirstName,LastName,EmailAddress,DateofBirth);
            Console.WriteLine($"Adult Status: {E1.IsAdult}");
            Console.WriteLine($"IsBirthday: {E1.IsBirthday}");
            Console.WriteLine($"Sunsign: {E1.SunSign}");
            Console.WriteLine($"Screen Name: {E1.ScreenName}");
            Console.WriteLine();

            double HRA, DA, Tax, NetPay;
            Console.WriteLine("Enter Permanent Employee Details:");
            Console.WriteLine("Enter HRA");
            HRA = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter DA");
            DA = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Tax");
            Tax = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Net Pay");
            NetPay = Convert.ToDouble(Console.ReadLine());

            PermanentEmployee p1 = new PermanentEmployee(HRA,DA,Tax,NetPay);
            double pay=p1.CalculatePay();
            Console.WriteLine($"Pay of Permanent Employee is {pay}");
            Console.WriteLine();


           double HoursWorked, payPerHour;
            Console.WriteLine("Enter Hourly Employee Details:");
            Console.WriteLine("Enter Hours Worked");
            HoursWorked = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter pay per Hour");
            payPerHour = Convert.ToDouble(Console.ReadLine());

            HourlyEmployee h1 = new HourlyEmployee(HoursWorked,payPerHour);
            pay = h1.CalculatePay();
            Console.WriteLine($"Pay of Permanent Employee is {pay}");
            Console.WriteLine();

        }

    }
}
