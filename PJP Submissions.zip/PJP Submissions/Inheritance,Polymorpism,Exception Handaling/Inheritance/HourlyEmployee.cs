﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inheritance
{
    class HourlyEmployee:IPayable
    {
        public double HoursWorked,payPerHour;

        public HourlyEmployee(double HoursWorked,double payPerHour)
        {
            this.HoursWorked = HoursWorked;
            this.payPerHour = payPerHour;
        }
        public double CalculatePay()
        {
            return HoursWorked * payPerHour;
        }
    }
}
