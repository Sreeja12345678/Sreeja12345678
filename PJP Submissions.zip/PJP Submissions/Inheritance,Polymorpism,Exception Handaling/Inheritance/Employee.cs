﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inheritance
{
    class Employee:Person
    {
        public double Salary;
    public Employee(string FirstName, string LastName, string EmailAddress, DateTime DateofBirth):base(FirstName,LastName,EmailAddress,DateofBirth)
    { 
    }
        
    }
}
