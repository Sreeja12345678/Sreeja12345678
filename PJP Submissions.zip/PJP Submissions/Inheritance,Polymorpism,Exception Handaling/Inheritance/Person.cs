﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inheritance
{
    class Person
    {
        public string FirstName, LastName, EmailAddress;
        public DateTime DateofBirth;

        readonly public bool IsAdult = true;
        readonly public string SunSign;
        readonly public bool IsBirthday = false;
        readonly public string ScreenName;
        public Person(string FirstName,string LastName,string EmailAddress,DateTime DateofBirth)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.EmailAddress = EmailAddress;
            this.DateofBirth = DateofBirth;
            this.ScreenName = this.FirstName;
            Console.WriteLine("Enter SunSign");
            SunSign = Console.ReadLine();
            Console.WriteLine("Are you an Adult(true/false)?");
            IsAdult = Convert.ToBoolean(Console.ReadLine());
            Console.WriteLine("Is Today is Your Birthday(true/false)?");
            IsBirthday = Convert.ToBoolean(Console.ReadLine());


        }

    }
}
